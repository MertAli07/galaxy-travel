//package assignment3;
import java.util.*;

public class SubspaceCommunicationNetwork {

    private List<SolarSystem> solarSystems;

    /**
     * Perform initializations regarding your implementation if necessary
     * @param solarSystems a list of SolarSystem objects
     */
    public SubspaceCommunicationNetwork(List<SolarSystem> solarSystems) {
        // TODO: YOUR CODE HERE
        this.solarSystems = solarSystems;
    }
    
    public static Planet findSmartest(SolarSystem s)
    {
    	int max = 0;
    	for(Planet p: s.getPlanets())
    	{
    		if(p.getTechnologyLevel() > max)
    		{
    			max = p.getTechnologyLevel();
    		}
    	}
    	for(Planet p: s.getPlanets())
    	{
    		if(p.getTechnologyLevel() == max)
    		{
    			return p;
    		}
    	}
    	return null;
    }

    public static double calculateCost(Planet p1, Planet p2)
    {
    	double i = p1.getTechnologyLevel();
    	double j = p2.getTechnologyLevel();
    	double avg = (i+j) / 2.0;
    	double cost = (Constants.SUBSPACE_COMMUNICATION_CONSTANT ) / (avg);
    	return cost;
    }
    
    public static void dfs(HashMap<String, ArrayList<String>> graph, String source, HashMap<String, Boolean> marked)
	{
		marked.put(source, true);
		if(!graph.containsKey(source))
		{
			return;
		}
		for(String s: graph.get(source))
		{
			if(!marked.get(s))
			{
				dfs(graph, s, marked);
			}
		}
	}
    
    public static boolean isCyclic(List<HyperChannel> mst, Planet source, Planet destination)
    {
    	if(mst.size() == 0)
    	{
    		return false;
    	}
    	HashMap<String, Boolean> marked = new HashMap<String, Boolean>();
    	for(HyperChannel p: mst)
    	{
    		marked.put(p.getFrom().getId(), false);
    		marked.put(p.getTo().getId(), false);
    	}
    	HashMap<String, ArrayList<String>> graph = new HashMap<String, ArrayList<String>>();
    	for(HyperChannel h: mst)
    	{
    		String v1 = h.getFrom().getId();
    		String v2 = h.getTo().getId();
    		if(graph.keySet().contains(v1) && graph.keySet().contains(v2))
    		{
    			graph.get(v1).add(v2);
    			graph.get(v2).add(v1);
    		}
    		else if(graph.keySet().contains(v1) && !graph.keySet().contains(v2))
    		{
    			graph.get(v1).add(v2);
    			graph.put(v2, new ArrayList<String>());
    			graph.get(v2).add(v1);
    		}
    		else if(!graph.keySet().contains(v1) && graph.keySet().contains(v2))
    		{
    			graph.get(v2).add(v1);
    			graph.put(v1, new ArrayList<String>());
    			graph.get(v1).add(v2);
    		}
    		else
    		{
    			graph.put(v1, new ArrayList<String>());
    			graph.get(v1).add(v2);
    			
    			graph.put(v2, new ArrayList<String>());
    			graph.get(v2).add(v1);
    		}
    	}
    	dfs(graph, source.getId(), marked);
    	if(!marked.keySet().contains(destination.getId()))
    	{
    		return false;
    	}
    	if(marked.get(destination.getId()))
    	{
    		return true;
    	}
    	return false;
    }
    /**
     * Using the solar systems of the network, generates a list of HyperChannel objects that constitute the minimum cost communication network.
     * @return A list HyperChannel objects that constitute the minimum cost communication network.
     */
    public List<HyperChannel> getMinimumCostCommunicationNetwork() {
        List<HyperChannel> minimumCostCommunicationNetwork = new ArrayList<>();
        // TODO: YOUR CODE HERE}
        ArrayList<Planet> vertices = new ArrayList<Planet>();
        for(SolarSystem s: solarSystems)
        {
        	Planet p = findSmartest(s);
        	vertices.add(p);
        }
        ArrayList<HyperChannel> edges = new ArrayList<HyperChannel>();
        for(int i = 0; i<vertices.size()-1; i++)
        {
        	for(int j = i+1; j < vertices.size(); j++)
        	{
        		HyperChannel h = new HyperChannel(vertices.get(j), vertices.get(i), calculateCost(vertices.get(i), vertices.get(j)));
        		edges.add(h);
        	}
        }
        
        
        Comparator<HyperChannel> edgeSorter = Comparator.comparing(HyperChannel::getWeight);
        PriorityQueue<HyperChannel> pq = new PriorityQueue<HyperChannel>(edgeSorter);
        for(HyperChannel h: edges)
        {
        	pq.add(h);
        }
        
        while(!pq.isEmpty() && minimumCostCommunicationNetwork.size() < vertices.size()-1)
        {
        	HyperChannel hyp = pq.poll();
        	Planet p1 = hyp.getFrom();
        	Planet p2 = hyp.getTo();
        	if(!isCyclic(minimumCostCommunicationNetwork, p1, p2))
        	{
        		minimumCostCommunicationNetwork.add(hyp);
        	}
        }
        return minimumCostCommunicationNetwork;
    }

    public void printMinimumCostCommunicationNetwork(List<HyperChannel> network) {
        double sum = 0;
        for (HyperChannel channel : network) {
            Planet[] planets = {channel.getFrom(), channel.getTo()};
            Arrays.sort(planets);
            System.out.printf("Hyperchannel between %s - %s with cost %f", planets[0], planets[1], channel.getWeight());
            System.out.println();
            sum += channel.getWeight();
        }
        System.out.printf("The total cost of the subspace communication network is %f.", sum);
        System.out.println();
    }
}

