//package assignment3;

import java.util.*;

public class Galaxy {

    private final List<Planet> planets;
    private List<SolarSystem> solarSystems;

    public Galaxy(List<Planet> planets) {
    	for(Planet p: planets)
        {
        	for(String n: p.getNeighbors())
        	{
        		for(Planet o: planets)
        		{
        			if(n.equals(o.getId()))
        			{
        				if(!o.getNeighbors().contains(p))
        				{
        					o.getNeighbors().add(p.getId());
        				}
        			}
        		}
        	}
        }
        this.planets = planets;
    }
    
    public static int getIndex(List<Planet> adj, String name)
    {
    	for(int i = 0; i<adj.size(); i++)
    	{
    		if(name.equals(adj.get(i).getId()))
    		{
    			return i;
    		}
    	}
    	return -1;
    }
    
    public static ArrayList<ArrayList<Planet>> cc(List<Planet> adj)
	{
		boolean[] marked = new boolean[adj.size()];
		int[] id = new int[adj.size()];
		for(int i = 0; i<marked.length; i++)
		{
			marked[i] = false;
			id[i] = 0;
		}
		int count = 0;
		for(int v = 0; v<adj.size(); v++)
		{
			if(!marked[v])
			{
				ccdfs(adj, v, marked, id, count++);
			}
		}
		
		ArrayList<ArrayList<Planet>> ps = new ArrayList<ArrayList<Planet>>();
		ps.add(new ArrayList<Planet>());
		int select = 0;
		for(int i = 0; i<adj.size(); i++)
		{
			if(id[i] == select)
			{
				ps.get(ps.size()-1).add(adj.get(i));
			}
			else
			{
				select = id[i];
				ps.add(new ArrayList<Planet>());
				ps.get(ps.size()-1).add(adj.get(i));
			}
		}
		return ps;
	}
	
	public static void ccdfs(List<Planet> adj, int v, boolean[] marked, int[] id, int count)
	{
		marked[v] = true;
		id[v] = count;
		for(String s: adj.get(v).getNeighbors())
		{
			int w = getIndex(adj, s);
			if(!marked[w])
			{
				ccdfs(adj, w, marked, id, count);
			}
		}
	}

    /**
     * Using the galaxy's list of Planet objects, explores all the solar systems in the galaxy.
     * Saves the result to the solarSystems instance variable and returns a shallow copy of it.
     *
     * @return List of SolarSystem objects.
     */
    public List<SolarSystem> exploreSolarSystems() {
        solarSystems = new ArrayList<>();
        // TODO: YOUR CODE HERE
        ArrayList<ArrayList<Planet>> ps = cc(planets);
        for(ArrayList<Planet> p: ps)
        {
        	SolarSystem s = new SolarSystem();
        	for(Planet pl: p)
        	{
        		s.addPlanet(pl);
        	}
        	solarSystems.add(s);
        }
        
        return new ArrayList<>(solarSystems);
    }

    public List<SolarSystem> getSolarSystems() {
        return solarSystems;
    }

    // FOR TESTING
    public List<Planet> getPlanets() {
        return planets;
    }

    // FOR TESTING
    public int getSolarSystemIndexByPlanetID(String planetId) {
        for (int i = 0; i < solarSystems.size(); i++) {
            SolarSystem solarSystem = solarSystems.get(i);
            if (solarSystem.hasPlanet(planetId)) {
                return i;
            }
        }
        return -1;
    }

    public void printSolarSystems(List<SolarSystem> solarSystems) {
        System.out.printf("%d solar systems have been discovered.%n", solarSystems.size());
        for (int i = 0; i < solarSystems.size(); i++) {
            SolarSystem solarSystem = solarSystems.get(i);
            List<Planet> planets = new ArrayList<>(solarSystem.getPlanets());
            Collections.sort(planets);
            System.out.printf("Planets in Solar System %d: %s", i + 1, planets);
            System.out.println();
        }
    }
}

