//package assignment3;

import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class MissionGroundwork {

    /**
     * Given a list of Project objects, prints the schedule of each of them.
     * Uses getEarliestSchedule() and printSchedule() methods of the current project to print its schedule.
     * @param projectList a list of Project objects
     */
    public void printSchedule(List<Project> projectList) {
        // TODO: YOUR CODE HERE
    	for(Project p: projectList)
    	{
    		p.printSchedule(p.getEarliestSchedule());
    	}
    }

    /**
     * TODO: Parse the input XML file and return a list of Project objects
     *
     * @param filename the input XML file
     * @return a list of Project objects
     */
    public List<Project> readXML(String filename) {
        List<Project> projectList = new ArrayList<>();
        try
        {
        	File fXmlFile = new File(filename);
        	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("Project");
            for (int temp = 0; temp < nList.getLength(); temp++)
            {
            	Node nNode = nList.item(temp);
            	if (nNode.getNodeType() == Node.ELEMENT_NODE)
            	{
            		Element eElement = (Element) nNode;
            		List <Task> ts = new ArrayList<Task>();
            		NodeList nList2 = eElement.getElementsByTagName("Task");
            		for (int i = 0; i < nList2.getLength(); i++)
            		{
            			Node nNode2 = nList2.item(i);
            			if (nNode2.getNodeType() == Node.ELEMENT_NODE)
            			{
            				Element eElement2 = (Element) nNode2;
            				List<Integer> deps = new ArrayList<Integer>();
            				
            				NodeList dps = eElement2.getElementsByTagName("Dependencies");
            				for(int j = 0; j < dps.getLength(); j++)
            				{
            					Node nNode3 = dps.item(j);
            					if(nNode3.getNodeType() == Node.ELEMENT_NODE)
            					{
            						Element el = (Element) nNode3;
            						if(dps.item(j).hasChildNodes())
            						{
            							for(int k = 0; k<dps.item(j).getChildNodes().getLength(); k++)
            							{
            								try
            								{
            									deps.add(Integer.parseInt(el.getElementsByTagName("DependsOnTaskID").item(k).getTextContent()));
            								}
            								catch(NullPointerException e)
            								{
            									continue;
            								}
            							}
            						}
            					}
            				}
            				
            				Task t = new Task(Integer.parseInt(eElement2.getElementsByTagName("TaskID").item(0).getTextContent()),
            						eElement2.getElementsByTagName("Description").item(0).getTextContent(),
            						Integer.parseInt(eElement2.getElementsByTagName("Duration").item(0).getTextContent()),
            						deps);
            				ts.add(t);
            			}
            		}
            		Project p = new Project(eElement.getElementsByTagName("Name").item(0).getTextContent(), ts);
            		projectList.add(p);
            	}
            }
        } catch(Exception e)
        {
        	e.printStackTrace();
        }
        return projectList;
    }


}

