//package assignment3;

import java.util.*;

public class Project {
    private final String name;
    private final List<Task> tasks;

    public Project(String name, List<Task> tasks) {
        this.name = name;
        this.tasks = tasks;
    }
    
    public static ArrayList<Integer> topological(ArrayList<ArrayList<Integer>> adj)
	{
		ArrayList<Integer> res = new ArrayList<Integer>();
		boolean[] marked = new boolean[adj.size()];
		for(int v = 0; v< adj.size(); v++)
		{
			if(!marked[v])
			{
				topdfs(adj, v, res, marked);
			}
		}
		//Collections.reverse(res);
		return res;
	}
	
	public static void topdfs(ArrayList<ArrayList<Integer>> adj, int v, ArrayList<Integer> res, boolean[] marked)
	{
		marked[v] = true;
		for(int w: adj.get(v))
		{
			if(!marked[w])
			{
				topdfs(adj, w, res, marked);
			}
		}
		res.add(v);
	}
	public static int findMax(ArrayList<Task> temp, int[] res)
	{
		int max = 0;
		for(int i = 0; i<temp.size(); i++)
		{
			if(temp.get(i).getDuration() + res[temp.get(i).getTaskID()] > max)
			{
				max = temp.get(i).getDuration() + res[temp.get(i).getTaskID()];
			}
		}
		return max;
	}

    /**
     * Schedule all tasks within this project such that they will be completed as early as possible.
     *
     * @return An integer array consisting of the earliest start days for each task.
     */
    public int[] getEarliestSchedule() {
        // TODO: YOUR CODE HERE
    	ArrayList<ArrayList<Integer>> adj = new ArrayList<ArrayList<Integer>>();
    	for(int i = 0; i<tasks.size(); i++)
    	{
    		ArrayList<Integer> tmp = new ArrayList<Integer>();
    		if(tasks.get(i).getDependencies().size() > 0)
    		{
    			for(int j: tasks.get(i).getDependencies())
        		{
        			tmp.add(j);
        		}
    		}
    		adj.add(tmp);
    	}
    	
    	ArrayList<Integer> top = topological(adj);
    	ArrayList<Task> t = new ArrayList<Task>();
    	for(int i = 0; i<top.size();i++)
    	{
    		for(int j = 0; j<top.size(); j++)
    		{
    			if(tasks.get(j).getTaskID() == top.get(i))
    			{
    				t.add(tasks.get(j));
    				break;
    			}
    		}
    	}
    	int[] res = new int[top.size()];
    	for(int i = 0; i<res.length; i++)
    	{
    		res[i] = 0;
    	}
    	
    	for(int i = 1; i<t.size(); i++)
    	{
    		ArrayList<Task> tmp = new ArrayList<Task>();
    		for(int j: t.get(i).getDependencies())
    		{
    			for(Task k: t)
    			{
    				if(k.getTaskID() == j)
    				{
    					tmp.add(k);
    				}
    			}
    		}
    		int time = findMax(tmp, res);
    		res[t.get(i).getTaskID()] = time;
    	}
        return res;
    }

    /**
     * @return the total duration of the project in days
     */
    public int getProjectDuration() {
        int projectDuration = 0;
        // TODO: YOUR CODE HERE
        int[] schedule = this.getEarliestSchedule();
        projectDuration = tasks.get(schedule.length - 1).getDuration() + schedule[schedule.length - 1];
        return projectDuration;
    }

    public static void printlnDash(int limit, char symbol) {
        for (int i = 0; i < limit; i++) System.out.print(symbol);
        System.out.println();
    }

    public void printSchedule(int[] schedule) {
        int limit = 65;
        char symbol = '-';
        printlnDash(limit, symbol);
        System.out.println(String.format("Project name: %s", name));
        printlnDash(limit, symbol);

        // Print header
        System.out.println(String.format("%-10s%-45s%-7s%-5s", "Task ID", "Description", "Start", "End"));
        printlnDash(limit, symbol);
        for (int i = 0; i < schedule.length; i++) {
            Task t = tasks.get(i);
            System.out.println(String.format("%-10d%-45s%-7d%-5d", i, t.getDescription(), schedule[i], schedule[i] + t.getDuration()));
        }
        printlnDash(limit, symbol);
        System.out.println(String.format("Project will be completed in %d days.", tasks.get(schedule.length - 1).getDuration() + schedule[schedule.length - 1]));
        printlnDash(limit, symbol);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Project project = (Project) o;

        int equal = 0;

        for (Task otherTask : ((Project) o).tasks) {
            if (tasks.stream().anyMatch(t -> t.equals(otherTask))) {
                equal++;
            }
        }

        return name.equals(project.name) && equal == tasks.size();
    }

}

