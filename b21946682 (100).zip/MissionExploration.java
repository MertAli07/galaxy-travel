//package assignment3;

import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class MissionExploration {

    /**
     * Given a Galaxy object, prints the solar systems within that galaxy.
     * Uses exploreSolarSystems() and printSolarSystems() methods of the Galaxy object.
     *
     * @param galaxy a Galaxy object
     */
    public void printSolarSystems(Galaxy galaxy) {
        // TODO: YOUR CODE HERE
    	galaxy.printSolarSystems(galaxy.exploreSolarSystems());
    }

    /**
     * TODO: Parse the input XML file and return a list of Planet objects.
     *
     * @param filename the input XML file
     * @return a list of Planet objects
     */
    public Galaxy readXML(String filename) {
        try 
        {
        	List<Planet> planetList = new ArrayList<>();
            File fXmlFile = new File(filename);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            
            NodeList nList = doc.getElementsByTagName("Planet");
            for(int i = 0; i<nList.getLength(); i++)
            {
            	Node nNode = nList.item(i);
            	if(nNode.getNodeType() == Node.ELEMENT_NODE)
            	{
            		Element el = (Element) nNode;
            		List<String> neighbors = new ArrayList<String>();
            		int size = el.getElementsByTagName("Neighbors").item(0).getChildNodes().getLength();
            		for(int j = 0; j<size; j++)
            		{
            			try
            			{
            				neighbors.add(el.getElementsByTagName("PlanetID").item(j).getTextContent());
            			}
            			catch(NullPointerException np)
            			{
            				continue;
            			}
            		}
            		Planet p = new Planet(el.getElementsByTagName("ID").item(0).getTextContent(),
            				Integer.parseInt(el.getElementsByTagName("TechnologyLevel").item(0).getTextContent()),
            				neighbors);
            		planetList.add(p);
            	}
            }
            
            return new Galaxy(planetList);
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        	return null;
        }
    }
}

